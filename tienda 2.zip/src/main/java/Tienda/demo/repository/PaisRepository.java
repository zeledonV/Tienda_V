/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda.demo.repository;


import Tienda.demo.entity.Pais;
import Tienda.demo.entity.personas;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author valer
 */
@Repository
public interface PaisRepository extends CrudRepository<Pais,Long>{
    personas findByNambre (String nombre);
}
