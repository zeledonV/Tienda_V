/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Tienda.demo.service;

import Tienda.demo.entity.Pais;
import java.util.List;

/**
 *
 * @author valer
 */
public interface IPaisService {

    public List<Pais> listCountry();
    
}
